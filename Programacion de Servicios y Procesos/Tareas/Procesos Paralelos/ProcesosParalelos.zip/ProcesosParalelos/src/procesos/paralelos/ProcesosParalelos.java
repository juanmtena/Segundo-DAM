/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package procesos.paralelos;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Usuario
 */
public class ProcesosParalelos {

    private int numInicial;
    private int numFinal;
    private String ficheroResultado;
    private Process p;

    public ProcesosParalelos (int numInicial, int numFinal, String ficheroResultado) {
    
        this.numInicial = numInicial;
        this.numFinal = numFinal;
        this.ficheroResultado = ficheroResultado;
        
        String clase = "procesos.paralelos.Sumador";
        String numI = String.valueOf(numInicial);
        String numF = String.valueOf(numFinal);
        
        ProcessBuilder pb = new ProcessBuilder("java", clase, numI, numF);
        
        pb.directory(new File("C:\\Users\\Usuario\\Documents\\NetBeansProjects\\ProcesosParalelos\\build\\classes"));
        
        pb.redirectOutput(new File(ficheroResultado));
        
        try {
            p = pb.start();
        } catch (IOException ex) {
            Logger.getLogger(ProcesosParalelos.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public int getResultadoSuma() throws IOException{
    
        int resultado = 0;
        
        try {
            FileReader lectorFichero = new FileReader(ficheroResultado);
            BufferedReader br = new BufferedReader(lectorFichero);
            String result = br.readLine();
            resultado = Integer.valueOf(result);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ProcesosParalelos.class.getName()).log(Level.SEVERE, null, ex);
        }
        return resultado;
    }

    public int getNumInicial() {
        return numInicial;
    }

    public void setNumInicial(int numInicial) {
        this.numInicial = numInicial;
    }

    public int getNumFinal() {
        return numFinal;
    }

    public void setNumFinal(int numFinal) {
        this.numFinal = numFinal;
    }

    public String getFicheroResultado() {
        return ficheroResultado;
    }

    public void setFicheroResultado(String ficheroResultado) {
        this.ficheroResultado = ficheroResultado;
    }

    public Process getP() {
        return p;
    }

    public void setP(Process p) {
        this.p = p;
    }
    
    
    
}
