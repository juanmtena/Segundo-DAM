/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package procesos.paralelos;

import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Usuario
 */
public class Principal {
    
    public static void main(String[] args) throws IOException {
    
            //Creo una variable para utilizarla en la suma
            int resultadoFinal = 0;
            
            //Pido que ingrese los 4 números
            Scanner teclado = new Scanner(System.in);
            System.out.println("Dime el primer número: ");
            int numero1 = teclado.nextInt();
            System.out.println("Dime el segundo número: ");
            int numero2 = teclado.nextInt();
            System.out.println("Dime el primer número: ");
            int numero3 = teclado.nextInt();
            System.out.println("Dime el segundo número: ");
            int numero4 = teclado.nextInt();
            
            //Creo los objetos a los que le paso por parámetros: los números y el fichero que voy a crear donde guardaré la suma de los números que hay entre los 2 números que le doy
            //Esta clase ya tiene el pb.star y por tanto lo ejecuta
            ProcesosParalelos p1 = new ProcesosParalelos(numero1 , numero2, "fichero.txt");
            ProcesosParalelos p2 = new ProcesosParalelos(numero3 , numero4, "fichero2.txt");
            
        try {
            //El waitFor es para decirle que esperen a que acaben
            p1.getP().waitFor();
            p2.getP().waitFor();
        } catch (InterruptedException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
    
        int primerResultado = p1.getResultadoSuma();
        int segundoResultado = p2.getResultadoSuma();
        
        resultadoFinal = primerResultado + segundoResultado;
        System.out.println("La suma total es: " + resultadoFinal);
    } 
    
}
