package start;

import java.util.ArrayList;
import java.util.List;

import model.Alumno;

public class Start {

	public static void main(String[] args) {

		ctrl.CtrlPrincipal.inicio();
		
		
		
	}
	
	public static ArrayList<String> crearalumnos() {
		
		ArrayList alumno = new ArrayList();
		
		alumno.add("Juan");
		
		return null;
	}
	
}
